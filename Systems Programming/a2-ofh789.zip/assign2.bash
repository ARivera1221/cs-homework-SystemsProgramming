#!/bin/bash

sed -i -E -f assign2.sed $@
